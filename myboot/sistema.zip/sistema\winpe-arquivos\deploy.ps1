<#
    deploy.ps1 - roda DENTRO do ambiente WinPE
    ===================================================================
    Le a tarefa deixada pelo sistema e executa em um de dois modos:

      TESTE  -> somente diagnostico. NAO toca em disco. (padrao)
      REAL   -> formata e aplica a imagem.

    O modo REAL so e acionado quando o arquivo tarefa.json pede
    explicitamente, e o sistema no Windows exige confirmacao dupla.
    ===================================================================
#>

$ErrorActionPreference = 'Stop'
$Script:Linhas = New-Object System.Collections.Generic.List[string]
$Script:Inicio = Get-Date

function Diz {
    param([string]$T = '', [string]$Cor = 'Gray')
    Write-Host $T -ForegroundColor $Cor
    $Script:Linhas.Add($T)
}
function Titulo($t) {
    Diz ''
    Diz ('=' * 65) Cyan
    Diz ("  $t") Cyan
    Diz ('=' * 65) Cyan
}
function Falha($t) { Diz "  [ERRO] $t" Red }
function Bom($t)   { Diz "  [OK]   $t" Green }
function Nota($t)  { Diz "  $t" Gray }

# =================================================================
#  LOCALIZAR A PASTA DE TRABALHO
# =================================================================
Clear-Host
Titulo 'SISTEMA DE FORMATACAO'
Diz "  Iniciado em $(Get-Date -Format 'dd/MM/yyyy HH:mm:ss')"

$Base = $null
foreach ($n in 67..90) {                        # C ate Z
    $l = [char]$n
    if (Test-Path "${l}:\SistemaFormatacao\arranque\MARCADOR.txt") {
        $Base = "${l}:\SistemaFormatacao\arranque"; break
    }
    if (Test-Path "${l}:\DEPLOY\MARCADOR.txt") {
        $Base = "${l}:\DEPLOY"; break
    }
}

if (-not $Base) {
    Falha 'Pasta de trabalho nao encontrada em nenhum volume.'
    Falha 'O sistema nao consegue continuar.'
    Nota  'Digite  wpeutil reboot  para voltar ao Windows.'
    return
}
Bom "Pasta de trabalho: $Base"

# =================================================================
#  LER A TAREFA
# =================================================================
$Tarefa = $null
$arqTarefa = Join-Path $Base 'tarefa.json'
if (Test-Path $arqTarefa) {
    try { $Tarefa = Get-Content $arqTarefa -Raw -Encoding UTF8 | ConvertFrom-Json } catch {}
}

$Modo = 'TESTE'
if ($Tarefa -and $Tarefa.Modo) { $Modo = $Tarefa.Modo.ToUpper() }

# Trava de seguranca: qualquer valor inesperado vira TESTE
if ($Modo -ne 'REAL') { $Modo = 'TESTE' }

Bom "Modo de operacao: $Modo"
if ($Modo -eq 'TESTE') {
    Diz '  (modo seguro - nenhum disco sera modificado)' Green
}

# =================================================================
#  DIAGNOSTICO (sempre roda, nos dois modos)
# =================================================================
Titulo 'DIAGNOSTICO DO EQUIPAMENTO'

$fw = (Get-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Control' -Name PEFirmwareType -ErrorAction SilentlyContinue).PEFirmwareType
$sb = (Get-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Control\SecureBoot\State' -Name UEFISecureBootEnabled -ErrorAction SilentlyContinue).UEFISecureBootEnabled

$fwTxt = switch ($fw) { 2 {'UEFI'} 1 {'BIOS Legacy'} default {'Indeterminado'} }
$sbTxt = switch ($sb) { 1 {'LIGADO'} 0 {'Desligado'} default {'N/D'} }

$cs  = Get-CimInstance Win32_ComputerSystem -ErrorAction SilentlyContinue
$bio = Get-CimInstance Win32_BIOS -ErrorAction SilentlyContinue

Diz "  Fabricante ....: $($cs.Manufacturer)"
Diz "  Modelo ........: $($cs.Model)"
Diz "  Numero de serie: $($bio.SerialNumber)"
Diz "  Memoria RAM ...: $([math]::Round($cs.TotalPhysicalMemory/1GB,1)) GB"
Diz "  Firmware ......: $fwTxt"
Diz "  Secure Boot ...: $sbTxt"
Diz ''

if ($sb -eq 1) {
    Diz '  >>> O ambiente carregou com Secure Boot LIGADO.' Green
    Diz '  >>> A arquitetura do sistema funciona neste equipamento.' Green
} elseif ($fw -eq 2) {
    Diz '  >>> Carregou em UEFI, mas com Secure Boot desligado.' Yellow
} else {
    Diz '  >>> Carregou em modo Legacy (BIOS antiga).' Yellow
}

# ------------------------------------------------- Discos
Titulo 'DISCOS DETECTADOS'
$discos = @(Get-Disk -ErrorAction SilentlyContinue | Sort-Object Number)

if ($discos.Count -eq 0) {
    Falha 'NENHUM DISCO DETECTADO.'
    Falha 'Falta driver de armazenamento neste equipamento.'
    Diz ''
    Nota 'Como resolver:'
    Nota '  1) Na BIOS, mude o modo SATA de RAID/RST para AHCI, ou'
    Nota '  2) Coloque o driver do fabricante na pasta "drivers" do'
    Nota '     sistema e monte o ambiente novamente.'
} else {
    foreach ($d in $discos) {
        Diz ("  Disco {0}: {1}" -f $d.Number, $d.FriendlyName)
        Diz ("           {0} | {1} | {2}" -f (
             "$([math]::Round($d.Size/1GB,1)) GB"), $d.BusType, $d.PartitionStyle)
    }
    Bom "$($discos.Count) disco(s) acessivel(is)"
}

# ------------------------------------------------- Rede (informativo)
$nics = @(Get-NetAdapter -ErrorAction SilentlyContinue | Where-Object { $_.Status -eq 'Up' })
if ($nics.Count -gt 0) { Nota "Rede: $($nics.Count) placa(s) ativa(s) - nao e necessario aqui" }

# =================================================================
#  MODO TESTE - termina aqui
# =================================================================
if ($Modo -eq 'TESTE') {
    Titulo 'TESTE CONCLUIDO'
    Diz '  Nenhum disco foi modificado.' Green
    $ok = $true
    $resumo = 'Teste de inicializacao concluido com sucesso.'
}

# =================================================================
#  MODO REAL - formata e aplica a imagem
# =================================================================
if ($Modo -eq 'REAL') {

    $ok = $false
    $resumo = ''

    try {
        Titulo 'APLICACAO DA IMAGEM'

        # ---------------------------------------- Validar a tarefa
        $imgArq = Join-Path $Base $Tarefa.ArquivoImagem
        if (-not (Test-Path $imgArq)) { throw "Imagem nao encontrada: $imgArq" }

        $indice = 1
        if ($Tarefa.Indice) { $indice = [int]$Tarefa.Indice }

        Bom "Imagem: $($Tarefa.NomeImagem)"
        Nota  "Arquivo: $($Tarefa.ArquivoImagem)"

        # ---------------------------------------- Identificar particoes
        $letraBase  = (Split-Path $Base -Qualifier).TrimEnd(':')
        $partBase   = Get-Partition -DriveLetter $letraBase -ErrorAction Stop
        $numDisco   = $partBase.DiskNumber
        $numPartBase= $partBase.PartitionNumber

        Nota "Area de trabalho: disco $numDisco, particao $numPartBase"

        $disco = Get-Disk -Number $numDisco
        if ($disco.Size -lt 40GB) { throw "Disco muito pequeno ($([math]::Round($disco.Size/1GB)) GB)." }

        Diz ''
        Diz '  ATENCAO: as demais particoes deste disco serao apagadas.' Yellow
        Diz ''

        # ---------------------------------------- Apagar particoes antigas
        Nota 'Removendo particoes anteriores...'
        $outras = @(Get-Partition -DiskNumber $numDisco |
                    Where-Object { $_.PartitionNumber -ne $numPartBase })
        foreach ($p in $outras) {
            try {
                Remove-Partition -DiskNumber $numDisco -PartitionNumber $p.PartitionNumber `
                                 -Confirm:$false -ErrorAction Stop
            } catch {
                Nota "  (particao $($p.PartitionNumber) resistiu, seguindo)"
            }
        }
        Bom 'Particoes anteriores removidas'

        # ---------------------------------------- Criar layout UEFI
        Nota 'Criando novo layout de particoes...'

        if ($fw -eq 2) {
            # --- EFI System Partition
            $esp = New-Partition -DiskNumber $numDisco -Size 300MB `
                   -GptType '{c12a7328-f81f-11d2-ba4b-00a0c93ec93b}' -ErrorAction Stop
            Format-Volume -Partition $esp -FileSystem FAT32 `
                   -NewFileSystemLabel 'SYSTEM' -Confirm:$false -ErrorAction Stop | Out-Null
            $esp | Set-Partition -NewDriveLetter 'S' -ErrorAction SilentlyContinue
            Bom 'Particao de sistema (EFI) criada'

            # --- Microsoft Reserved
            New-Partition -DiskNumber $numDisco -Size 16MB `
                   -GptType '{e3c9e316-0b5c-4db8-817d-f92df00215ae}' -ErrorAction Stop | Out-Null
            Bom 'Particao reservada criada'
        }

        # --- Particao do Windows (maior espaco livre restante)
        $win = New-Partition -DiskNumber $numDisco -UseMaximumSize `
               -GptType '{ebd0a0a2-b9e5-4433-87c0-68b6b72699c7}' -ErrorAction Stop
        Format-Volume -Partition $win -FileSystem NTFS `
               -NewFileSystemLabel 'Windows' -Confirm:$false -ErrorAction Stop | Out-Null
        $win | Set-Partition -NewDriveLetter 'W' -ErrorAction SilentlyContinue
        Bom ("Particao do Windows criada ({0} GB)" -f [math]::Round($win.Size/1GB,1))

        Start-Sleep -Seconds 3

        # ---------------------------------------- Aplicar a imagem
        Titulo 'GRAVANDO O WINDOWS'
        Diz '  Isto leva de 4 a 15 minutos. Nao desligue o equipamento.' Yellow
        Diz ''

        $dismLog = Join-Path $Base 'dism.log'
        & dism.exe /Apply-Image /ImageFile:"$imgArq" /Index:$indice /ApplyDir:W:\ /LogPath:"$dismLog"
        if ($LASTEXITCODE -ne 0) { throw "DISM falhou com codigo $LASTEXITCODE. Veja $dismLog" }
        Bom 'Imagem gravada'

        # ---------------------------------------- Drivers
        $pastaDrv = Join-Path $Base 'drivers'
        if (Test-Path $pastaDrv) {
            $infs = @(Get-ChildItem $pastaDrv -Filter *.inf -Recurse -ErrorAction SilentlyContinue)
            if ($infs.Count -gt 0) {
                Nota "Injetando $($infs.Count) driver(s)..."
                & dism.exe /Image:W:\ /Add-Driver /Driver:"$pastaDrv" /Recurse /ForceUnsigned | Out-Null
                Bom 'Drivers injetados'
            }
        }

        # ---------------------------------------- unattend.xml
        $ua = Join-Path $Base 'unattend.xml'
        if (Test-Path $ua) {
            $panther = 'W:\Windows\Panther'
            if (-not (Test-Path $panther)) { New-Item -ItemType Directory -Path $panther -Force | Out-Null }
            Copy-Item $ua (Join-Path $panther 'unattend.xml') -Force
            Bom 'Configuracao automatica aplicada (unattend.xml)'
        } else {
            Nota 'Sem unattend.xml - o Windows vai pedir configuracao inicial'
        }

        # ---------------------------------------- Bootloader
        Nota 'Criando o carregador de inicializacao...'
        if ($fw -eq 2) { & bcdboot.exe W:\Windows /s S: /f UEFI }
        else           { & bcdboot.exe W:\Windows /s W: /f BIOS }
        if ($LASTEXITCODE -ne 0) { throw "bcdboot falhou com codigo $LASTEXITCODE" }
        Bom 'Carregador criado'

        $ok = $true
        $resumo = "Windows aplicado com sucesso: $($Tarefa.NomeImagem)"
        Titulo 'FORMATACAO CONCLUIDA'
        Diz '  O equipamento vai reiniciar no Windows novo.' Green
    }
    catch {
        $ok = $false
        $resumo = "FALHA: $_"
        Titulo 'FALHA NA FORMATACAO'
        Falha "$_"
        Diz ''
        Nota 'O disco pode estar em estado incompleto.'
        Nota 'Anote a mensagem acima antes de reiniciar.'
    }
}

# =================================================================
#  RELATORIO
# =================================================================
$dur = [math]::Round(((Get-Date) - $Script:Inicio).TotalMinutes, 1)

$resultado = [ordered]@{
    Modo          = $Modo
    Sucesso       = $ok
    Resumo        = $resumo
    Firmware      = $fwTxt
    SecureBoot    = $sbTxt
    DiscosVistos  = $discos.Count
    Fabricante    = "$($cs.Manufacturer)"
    Modelo        = "$($cs.Model)"
    Serie         = "$($bio.SerialNumber)"
    DuracaoMin    = $dur
    Quando        = (Get-Date -Format 's')
}

$carimbo = Get-Date -Format 'yyyyMMdd-HHmmss'
try {
    $resultado | ConvertTo-Json -Depth 4 | Out-File (Join-Path $Base "resultado-$carimbo.json") -Encoding UTF8
    $Script:Linhas | Out-File (Join-Path $Base "relatorio-$carimbo.txt") -Encoding UTF8
    Bom "Relatorio salvo em $Base"
} catch {
    Nota 'Nao foi possivel salvar o relatorio (tire uma foto da tela).'
}

# =================================================================
#  REINICIAR
# =================================================================
Diz ''
Diz ('=' * 65) Cyan
Diz "  Duracao: $dur minutos"
Diz '  Reiniciando automaticamente. Pressione uma tecla para ir agora.' White
Diz ('=' * 65) Cyan

$espera = 60
$fim = (Get-Date).AddSeconds($espera)
while ((Get-Date) -lt $fim) {
    if ($Host.UI.RawUI.KeyAvailable) { $null = $Host.UI.RawUI.ReadKey('NoEcho,IncludeKeyDown'); break }
    $r = [int]((($fim) - (Get-Date)).TotalSeconds)
    Write-Host ("`r  Reiniciando em {0} segundos...   " -f $r) -NoNewline -ForegroundColor DarkGray
    Start-Sleep -Milliseconds 500
}
Write-Host ''
wpeutil reboot
