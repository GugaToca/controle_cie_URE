<#
    disco.ps1 - Criacao e remocao da area de trabalho em disco

    A "area de staging" e uma particao temporaria que guarda o ambiente
    de boot e a imagem do Windows. Ela precisa existir separada do C:
    porque o C: e justamente o que sera formatado.

    Depois da formatacao ela e removida e o espaco devolvido ao C:.
#>

function Obter-LetraLivre {
    $usadas = @(Get-Volume | Where-Object { $_.DriveLetter } | ForEach-Object { $_.DriveLetter })
    foreach ($n in 90..68) {                 # Z ate D, de tras pra frente
        $l = [char]$n
        if ($usadas -notcontains $l) { return $l }
    }
    return $null
}

function Obter-AreaStaging {
    <# Devolve a particao de staging existente, ou $null. #>
    $v = Get-Volume -ErrorAction SilentlyContinue |
         Where-Object { $_.FileSystemLabel -eq 'DEPLOY' -and $_.DriveLetter }
    if ($v) { return ($v | Select-Object -First 1) }
    return $null
}

function Criar-AreaStaging {
    <#
      Encolhe o C: e cria uma particao rotulada DEPLOY.
      Devolve a letra da particao, ou $null em caso de falha.
    #>
    param(
        [Parameter(Mandatory)][double]$GbNecessarios
    )

    Escrever-Log "=========================================" PASSO
    Escrever-Log " PREPARANDO AREA DE TRABALHO EM DISCO" PASSO
    Escrever-Log "=========================================" PASSO

    # Ja existe?
    $ja = Obter-AreaStaging
    if ($ja) {
        $livreGb = [math]::Round($ja.SizeRemaining/1GB,1)
        Escrever-Log "Area DEPLOY ja existe em $($ja.DriveLetter): ($livreGb GB livres)" OK
        if ($livreGb -ge $GbNecessarios) { return $ja.DriveLetter }

        Escrever-Log "Area existente e pequena demais. Removendo para recriar." AVISO
        if (-not (Remover-AreaStaging)) { return $null }
    }

    # Quem chama ja somou a folga necessaria. Aqui vai so meio giga
    # para o proprio sistema de arquivos (tabelas, cluster perdido).
    $bytesNec = [int64](($GbNecessarios + 0.5) * 1GB)

    try {
        $partC = Get-Partition -DriveLetter C -ErrorAction Stop
    } catch {
        Escrever-Log "Nao consegui acessar a particao C:" ERRO
        return $null
    }

    # Cabe encolher?
    $sup = Get-PartitionSupportedSize -DriveLetter C -ErrorAction SilentlyContinue
    if (-not $sup) { Escrever-Log "Nao consegui calcular o redimensionamento do C:" ERRO; return $null }

    $podeLiberar = $partC.Size - $sup.SizeMin
    Escrever-Log ("C: pode liberar ate {0}" -f (Formatar-Tamanho $podeLiberar)) INFO
    Escrever-Log ("Necessario: {0}" -f (Formatar-Tamanho $bytesNec)) INFO

    if ($podeLiberar -lt $bytesNec) {
        Escrever-Log "Espaco insuficiente no C: para criar a area de trabalho." ERRO
        Escrever-Log "Libere espaco (limpar temporarios, desfragmentar) e tente de novo." INFO
        return $null
    }

    $novoTamC = $partC.Size - $bytesNec

    Escrever-Log "Encolhendo o C: (pode levar alguns minutos)..." PASSO
    try {
        Resize-Partition -DriveLetter C -Size $novoTamC -ErrorAction Stop
    } catch {
        Escrever-Log "Falha ao encolher o C: $_" ERRO
        Escrever-Log "Causa comum: arquivos do sistema no fim do disco." INFO
        Escrever-Log "Tente desativar hibernacao e restauracao do sistema, depois repita." INFO
        return $null
    }
    Escrever-Log "C: redimensionado" OK

    Escrever-Log "Criando a particao de trabalho..." PASSO
    try {
        $nova = New-Partition -DiskNumber $partC.DiskNumber -UseMaximumSize -ErrorAction Stop
        Start-Sleep -Seconds 2

        $letra = Obter-LetraLivre
        if (-not $letra) { throw "Nenhuma letra de unidade disponivel." }

        $nova | Set-Partition -NewDriveLetter $letra -ErrorAction Stop
        Start-Sleep -Seconds 2

        Format-Volume -DriveLetter $letra -FileSystem NTFS `
              -NewFileSystemLabel 'DEPLOY' -Confirm:$false -ErrorAction Stop | Out-Null
    } catch {
        Escrever-Log "Falha ao criar a particao: $_" ERRO
        return $null
    }

    Escrever-Log "Area de trabalho criada em ${letra}: (rotulo DEPLOY)" OK
    return $letra
}

function Remover-AreaStaging {
    <# Apaga a particao DEPLOY e devolve o espaco ao C:. #>

    $v = Obter-AreaStaging
    if (-not $v) { Escrever-Log "Nenhuma area DEPLOY encontrada" INFO; return $true }

    $letra = $v.DriveLetter
    Escrever-Log "Removendo area de trabalho ${letra}: ..." PASSO

    try {
        $p = Get-Partition -DriveLetter $letra -ErrorAction Stop
        $disco = $p.DiskNumber
        Remove-Partition -DiskNumber $disco -PartitionNumber $p.PartitionNumber `
                         -Confirm:$false -ErrorAction Stop
        Escrever-Log "Particao removida" OK
    } catch {
        Escrever-Log "Falha ao remover a particao: $_" ERRO
        return $false
    }

    Start-Sleep -Seconds 2

    Escrever-Log "Devolvendo o espaco ao C: ..." PASSO
    try {
        $sup = Get-PartitionSupportedSize -DriveLetter C -ErrorAction Stop
        Resize-Partition -DriveLetter C -Size $sup.SizeMax -ErrorAction Stop
        Escrever-Log "C: estendido de volta" OK
    } catch {
        Escrever-Log "Nao consegui estender o C: automaticamente: $_" AVISO
        Escrever-Log "Use o Gerenciamento de Disco do Windows para estender manualmente." INFO
    }
    return $true
}
