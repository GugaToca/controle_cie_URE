<#
    midia.ps1 - Importa a midia de instalacao do Windows

    Aceita:
      - arquivo .zip contendo a estrutura de uma midia (Sources\, Boot\, EFI\)
      - arquivo .iso
      - pasta ja extraida
      - pen drive / DVD montado

    Do conteudo, o sistema precisa de:
      Sources\boot.wim          -> vira o ambiente de formatacao
      Sources\Install.wim  ou
      Sources\Install*.swm      -> a imagem do Windows a ser gravada
#>

function Testar-Midia {
    <# Confere se uma pasta tem a estrutura esperada. #>
    param([Parameter(Mandatory)][string]$Pasta)

    $src = Join-Path $Pasta 'Sources'
    if (-not (Test-Path $src)) {
        # Algumas midias usam minusculo ou tem uma pasta a mais por dentro
        $alt = @(Get-ChildItem $Pasta -Directory -ErrorAction SilentlyContinue |
                 Where-Object { Test-Path (Join-Path $_.FullName 'Sources') })
        if ($alt.Count -gt 0) {
            $Pasta = $alt[0].FullName
            $src = Join-Path $Pasta 'Sources'
        } else {
            return $null
        }
    }

    $bootWim = Get-ChildItem $src -Filter 'boot.wim' -ErrorAction SilentlyContinue | Select-Object -First 1

    $inst = Get-ChildItem $src -ErrorAction SilentlyContinue |
            Where-Object { $_.Name -match '^install.*\.(wim|esd|swm)$' } |
            Sort-Object Name

    # Numa imagem dividida, a parte 1 e a que nao tem numero (Install.swm)
    $principal = $inst | Where-Object { $_.Name -match '^install\.(wim|esd|swm)$' } | Select-Object -First 1
    if (-not $principal) { $principal = $inst | Select-Object -First 1 }

    if (-not $principal) { return $null }

    return [pscustomobject]@{
        Pasta       = $Pasta
        Sources     = $src
        BootWim     = $(if ($bootWim) { $bootWim.FullName } else { $null })
        Imagem      = $principal.FullName
        ImagemNome  = $principal.Name
        Dividida    = ($principal.Extension -eq '.swm')
        Partes      = $inst.Count
        TamanhoTotal= ($inst | Measure-Object Length -Sum).Sum
    }
}

function Obter-EdicoesImagem {
    <# Le as edicoes dentro de um .wim / .swm. #>
    param([Parameter(Mandatory)][string]$Arquivo)
    try {
        return @(Get-WindowsImage -ImagePath $Arquivo -ErrorAction Stop)
    } catch {
        Escrever-Log "Nao consegui ler as edicoes de $Arquivo : $_" AVISO -SemConsole
        return @()
    }
}

function Importar-Midia {
    <#
      Extrai / copia a midia para C:\SistemaFormatacao\midias\<nome>
      Devolve o objeto da midia importada, ou $null.
    #>
    param(
        [Parameter(Mandatory)][string]$Origem,
        [string]$Nome
    )

    $destRaiz = Join-Path $Global:DADOS 'midias'
    if (-not (Test-Path $destRaiz)) { New-Item -ItemType Directory -Path $destRaiz -Force | Out-Null }

    if (-not $Nome) {
        $Nome = [System.IO.Path]::GetFileNameWithoutExtension($Origem)
        $Nome = ($Nome -replace '[^\w\-\.]', '_')
        if ($Nome.Length -gt 60) { $Nome = $Nome.Substring(0,60) }
    }
    $destino = Join-Path $destRaiz $Nome

    Escrever-Log "=========================================" PASSO
    Escrever-Log " IMPORTANDO A MIDIA DE INSTALACAO" PASSO
    Escrever-Log "=========================================" PASSO
    Escrever-Log "Origem : $Origem" INFO
    Escrever-Log "Destino: $destino" INFO

    $item = Get-Item $Origem -ErrorAction SilentlyContinue
    if (-not $item) { Escrever-Log "Origem nao encontrada." ERRO; return $null }

    # ---------------------------------------------------- Espaco livre
    $precisa = 0
    if ($item.PSIsContainer) {
        $precisa = (Get-ChildItem $Origem -Recurse -File -ErrorAction SilentlyContinue |
                    Measure-Object Length -Sum).Sum
    } else {
        # ZIP: assume que expande para ~1.1x o tamanho do arquivo
        $precisa = [int64]($item.Length * 1.1)
    }

    $letraDest = (Split-Path $destRaiz -Qualifier)[0]
    $livre = (Get-PSDrive $letraDest).Free
    Escrever-Log ("Necessario: {0} | Livre: {1}" -f (Formatar-Tamanho $precisa), (Formatar-Tamanho $livre)) INFO

    if ($livre -lt ($precisa + 5GB)) {
        Escrever-Log "Espaco insuficiente em ${letraDest}: para importar a midia." ERRO
        Escrever-Log "Libere espaco ou use um HD externo." INFO
        return $null
    }

    if (Test-Path $destino) {
        Escrever-Log "Ja existe uma pasta com esse nome. Removendo para reimportar..." AVISO
        Remove-Item $destino -Recurse -Force -ErrorAction SilentlyContinue
    }
    New-Item -ItemType Directory -Path $destino -Force | Out-Null

    # ---------------------------------------------------- Extrair / copiar
    try {
        if ($item.PSIsContainer) {
            Escrever-Log "Copiando arquivos (pode levar varios minutos)..." PASSO
            Copy-Item (Join-Path $Origem '*') $destino -Recurse -Force -ErrorAction Stop
        }
        elseif ($item.Extension -eq '.zip') {
            Escrever-Log "Extraindo o arquivo ZIP." PASSO
            Escrever-Log "Sao 14 GB - isto leva de 10 a 30 minutos. Nao feche esta janela." AVISO
            Add-Type -AssemblyName System.IO.Compression.FileSystem
            [System.IO.Compression.ZipFile]::ExtractToDirectory($item.FullName, $destino)
        }
        elseif ($item.Extension -eq '.iso') {
            Escrever-Log "Montando o arquivo ISO..." PASSO
            $mnt = Mount-DiskImage -ImagePath $item.FullName -PassThru -ErrorAction Stop
            $letra = ($mnt | Get-Volume).DriveLetter
            Escrever-Log "ISO montado em ${letra}:" OK
            Copy-Item "${letra}:\*" $destino -Recurse -Force -ErrorAction Stop
            Dismount-DiskImage -ImagePath $item.FullName -ErrorAction SilentlyContinue | Out-Null
        }
        else {
            Escrever-Log "Formato nao reconhecido: $($item.Extension)" ERRO
            Escrever-Log "Use um .zip, um .iso ou aponte para a pasta ja extraida." INFO
            return $null
        }
    }
    catch {
        Escrever-Log "Falha ao importar: $_" ERRO
        return $null
    }

    Escrever-Log "Conteudo copiado" OK

    # ---------------------------------------------------- Validar
    Escrever-Log "Conferindo a estrutura da midia..." PASSO
    $m = Testar-Midia -Pasta $destino
    if (-not $m) {
        Escrever-Log "Nao encontrei Sources\install.wim nem Sources\Install*.swm." ERRO
        Escrever-Log "Esta midia nao tem o formato esperado." INFO
        return $null
    }

    Escrever-Log "Imagem do Windows: $($m.ImagemNome)" OK
    if ($m.Dividida) { Escrever-Log "Imagem dividida em $($m.Partes) partes (formato SWM)" OK }
    if ($m.BootWim)  { Escrever-Log "Ambiente de boot proprio encontrado (nao precisa do Windows ADK)" OK }
    else             { Escrever-Log "Sem boot.wim na midia - sera necessario o Windows ADK" AVISO }

    $eds = Obter-EdicoesImagem -Arquivo $m.Imagem
    if ($eds.Count -gt 0) {
        Escrever-Log "Edicoes encontradas:" OK
        foreach ($e in $eds) { Escrever-Log ("  [{0}] {1}" -f $e.ImageIndex, $e.ImageName) INFO }
    }

    # ---------------------------------------------------- Registrar
    $reg = [ordered]@{
        Nome        = $Nome
        Pasta       = $m.Pasta
        Imagem      = $m.Imagem
        ImagemNome  = $m.ImagemNome
        Dividida    = $m.Dividida
        Partes      = $m.Partes
        BootWim     = $m.BootWim
        Tamanho     = $m.TamanhoTotal
        Edicoes     = @($eds | ForEach-Object { @{ Indice = $_.ImageIndex; Nome = $_.ImageName } })
        ImportadoEm = (Get-Date -Format 's')
    }
    $reg | ConvertTo-Json -Depth 6 | Out-File (Join-Path $destino 'midia.json') -Encoding UTF8 -Force

    Escrever-Log "=========================================" OK
    Escrever-Log " MIDIA IMPORTADA COM SUCESSO" OK
    Escrever-Log "=========================================" OK
    return $reg
}

function Obter-UrlSite {
    <#
      Descobre o endereco do site. O instalador.bat grava em site.txt.
      Se nao houver, usa o que estiver salvo na configuracao.
    #>
    foreach ($p in @(
        (Join-Path $Global:RAIZ 'site.txt'),
        (Join-Path $Global:DADOS 'site.txt'),
        'C:\ProgramData\SistemaFormatacao\site.txt')) {
        if (Test-Path $p) {
            $u = (Get-Content $p -Raw -ErrorAction SilentlyContinue).Trim()
            if ($u) { return $u.TrimEnd('/') }
        }
    }
    $cfg = Ler-Config
    if ($cfg.UrlCatalogo) { return ($cfg.UrlCatalogo -replace '/catalogo\.json$','').TrimEnd('/') }
    return $null
}

function Obter-CatalogoWeb {
    <# Le o catalogo.json publicado no site. #>
    param([string]$UrlSite)

    if (-not $UrlSite) { $UrlSite = Obter-UrlSite }
    if (-not $UrlSite) { Escrever-Log "Endereco do site nao configurado." ERRO; return $null }

    $url = "$($UrlSite.TrimEnd('/'))/catalogo.json"
    try {
        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
        $c = Invoke-RestMethod -Uri $url -TimeoutSec 30 -ErrorAction Stop
        Escrever-Log "Catalogo lido: $(@($c.imagens).Count) imagem(ns) publicada(s)" OK

        $cfg = Ler-Config
        $cfg.UrlCatalogo = $url
        Salvar-Config $cfg

        return $c
    } catch {
        Escrever-Log "Nao consegui ler o catalogo em $url : $_" ERRO
        return $null
    }
}

function Importar-MidiaDaWeb {
    <#
      Baixa uma imagem publicada no catalogo e monta a estrutura de midia
      em C:\SistemaFormatacao\midias\<id>\
    #>
    param(
        [Parameter(Mandatory)]$Catalogo,
        [Parameter(Mandatory)][string]$ImagemId
    )

    $img = @($Catalogo.imagens) | Where-Object { $_.id -eq $ImagemId } | Select-Object -First 1
    if (-not $img) { Escrever-Log "Imagem '$ImagemId' nao esta no catalogo." ERRO; return $null }

    $base = $Catalogo.urlBase
    if (-not $base) { Escrever-Log "O catalogo nao tem 'urlBase'." ERRO; return $null }
    $base = $base.TrimEnd('/')

    Escrever-Log "=========================================" PASSO
    Escrever-Log " BAIXANDO A IMAGEM DA INTERNET" PASSO
    Escrever-Log "=========================================" PASSO
    Escrever-Log "Imagem: $($img.nome)" INFO
    if ($img.tamanhoBytes) { Escrever-Log ("Tamanho total: {0}" -f (Formatar-Tamanho $img.tamanhoBytes)) INFO }

    # ---------------------------------------------------- Area de trabalho
    #
    # A imagem e baixada DIRETO para a particao DEPLOY.
    #
    # Antes: baixava no C:, depois encolhia o C: e copiava tudo de novo para
    # a DEPLOY. A mesma imagem existia duas vezes no disco ao mesmo tempo,
    # exigindo mais de 30 GB livres num caso de 13 GB.
    #
    # Agora: cria a area primeiro e baixa dentro dela. Na hora de formatar,
    # os arquivos so mudam de pasta dentro da MESMA particao, o que e
    # instantaneo e nao gasta espaco nenhum.

    $precisa = [int64]$img.tamanhoBytes
    if ($precisa -le 0) { $precisa = 15GB }

    # Folga de 1 GB. O tamanho do catalogo ja inclui tudo que sera
    # baixado; aqui sobra so para logs e o relatorio do WinPE.
    $gb = [math]::Ceiling($precisa / 1GB) + 1
    Escrever-Log ("Imagem: {0} GB / area de trabalho: {1} GB" -f
        [math]::Round($precisa/1GB,1), $gb) INFO

    $letra = Criar-AreaStaging -GbNecessarios $gb
    if (-not $letra) {
        Escrever-Log "Nao consegui preparar a area de trabalho em disco." ERRO
        Escrever-Log "Libere espaco no C: e tente de novo." INFO
        return $null
    }

    # ---------------------------------------------------- Pastas
    $nome    = ($img.id -replace '[^\w\-\.]','_')
    $destino = "${letra}:\DEPLOY"
    $src     = Join-Path $destino 'Sources'
    $bootDir = Join-Path $destino 'Boot'

    # O cadastro continua no C:, e o menu que le essa pasta.
    # Os arquivos grandes ficam na DEPLOY.
    $regDir = Join-Path (Join-Path $Global:DADOS 'midias') $nome

    $peDir = Join-Path $destino 'winpe'

    foreach ($p in @($destino,$src,$bootDir,$regDir,$peDir)) {
        if (-not (Test-Path $p)) { New-Item -ItemType Directory -Path $p -Force | Out-Null }
    }

    Escrever-Log "Baixando direto para a area de trabalho ${letra}:" OK

    # ---------------------------------------------------- Downloads
    $tarefas = @()
    if ($img.bootWim) { $tarefas += @{ U="$base/$($img.bootWim)"; D=(Join-Path $src 'boot.wim');     N='Ambiente de boot' } }
    if ($img.bootSdi) { $tarefas += @{ U="$base/$($img.bootSdi)"; D=(Join-Path $bootDir 'boot.sdi'); N='boot.sdi' } }

    # Ambiente ja montado no servidor. Evita 5 a 15 minutos de montagem
    # em cada maquina. Se o catalogo nao oferecer, monta local como antes.
    $peWim = $null
    $peSdi = $null
    if ($img.winpeWim) {
        $peWim = Join-Path $peDir 'boot.wim'
        $tarefas += @{ U="$base/$($img.winpeWim)"; D=$peWim; N='Ambiente de formatacao (pronto)' }
    }
    if ($img.winpeSdi) {
        $peSdi = Join-Path $peDir 'boot.sdi'
        $tarefas += @{ U="$base/$($img.winpeSdi)"; D=$peSdi; N='Ambiente pronto - boot.sdi' }
    }

    $n = 0
    foreach ($a in @($img.arquivos)) {
        $n++
        $arqNome = Split-Path $a -Leaf
        $tarefas += @{ U="$base/$a"; D=(Join-Path $src $arqNome); N="Imagem parte $n" }
    }
    if ($img.unattend) { $tarefas += @{ U="$base/$($img.unattend)"; D=(Join-Path $src 'unattend.xml'); N='Configuracao automatica' } }

    $i = 0
    foreach ($t in $tarefas) {
        $i++
        Escrever-Log "[$i/$($tarefas.Count)] $($t.N)" PASSO

        # Ja baixado e com tamanho plausivel? pula
        if (Test-Path $t.D) {
            Escrever-Log "  ja existe, verificando..." INFO
        }

        if (-not (Baixar-Arquivo -Url $t.U -Destino $t.D -Descricao $t.N)) {
            Escrever-Log "Falha ao baixar: $($t.U)" ERRO
            return $null
        }
    }

    # ---------------------------------------------------- Validar
    Escrever-Log "Conferindo a estrutura..." PASSO
    $m = Testar-Midia -Pasta $destino
    if (-not $m) {
        Escrever-Log "Os arquivos baixados nao formam uma midia valida." ERRO
        return $null
    }

    $eds = Obter-EdicoesImagem -Arquivo $m.Imagem
    foreach ($e in $eds) { Escrever-Log ("  [{0}] {1}" -f $e.ImageIndex, $e.ImageName) INFO }

    $reg = [ordered]@{
        Nome        = $nome
        Rotulo      = $img.nome
        Pasta       = $m.Pasta
        Imagem      = $m.Imagem
        ImagemNome  = $m.ImagemNome
        Dividida    = $m.Dividida
        Partes      = $m.Partes
        BootWim     = $m.BootWim
        Tamanho     = $m.TamanhoTotal
        Origem      = 'internet'
        NaAreaDeploy= $true
        WinPEProntoWim = $(if ($peWim -and (Test-Path $peWim)) { $peWim } else { $null })
        WinPEProntoSdi = $(if ($peSdi -and (Test-Path $peSdi)) { $peSdi } else { $null })
        Edicoes     = @($eds | ForEach-Object { @{ Indice = $_.ImageIndex; Nome = $_.ImageName } })
        ImportadoEm = (Get-Date -Format 's')
    }
    # O cadastro vai para o C:, onde o menu procura. Os arquivos ficam na DEPLOY.
    $reg | ConvertTo-Json -Depth 6 | Out-File (Join-Path $regDir 'midia.json') -Encoding UTF8 -Force

    Escrever-Log "=========================================" OK
    Escrever-Log " IMAGEM BAIXADA COM SUCESSO" OK
    Escrever-Log "=========================================" OK
    return $reg
}

function Listar-Midias {
    <# Lista as midias ja importadas. #>
    $raiz = Join-Path $Global:DADOS 'midias'
    if (-not (Test-Path $raiz)) { return @() }

    $res = @()
    foreach ($d in (Get-ChildItem $raiz -Directory -ErrorAction SilentlyContinue)) {
        $j = Join-Path $d.FullName 'midia.json'
        if (Test-Path $j) {
            try { $res += (Get-Content $j -Raw -Encoding UTF8 | ConvertFrom-Json) } catch {}
        }
    }
    return $res
}
