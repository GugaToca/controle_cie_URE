<#
    comum.ps1 - Funcoes compartilhadas do sistema
    Compativel com PowerShell 5.1 (o que vem no Windows)
#>

# ============================================================ CAMINHOS

$Global:RAIZ      = Split-Path (Split-Path $PSScriptRoot -Parent) -Parent
$Global:SISTEMA   = Join-Path $RAIZ 'sistema'
$Global:DADOS     = 'C:\SistemaFormatacao'
$Global:PASTA_LOG = Join-Path $DADOS 'logs'
$Global:PASTA_PE  = Join-Path $DADOS 'winpe'
$Global:PASTA_IMG = Join-Path $DADOS 'imagens'
$Global:CFG_ARQ   = Join-Path $DADOS 'config.json'

foreach ($p in @($DADOS, $PASTA_LOG, $PASTA_PE, $PASTA_IMG)) {
    if (-not (Test-Path $p)) { New-Item -ItemType Directory -Path $p -Force | Out-Null }
}

$Global:LOG_ATUAL = Join-Path $PASTA_LOG ("log-{0}.txt" -f (Get-Date -Format 'yyyyMMdd'))

# ============================================================ LOG

function Escrever-Log {
    param(
        [Parameter(Mandatory)][string]$Texto,
        [ValidateSet('INFO','OK','AVISO','ERRO','PASSO')][string]$Nivel = 'INFO',
        [switch]$SemConsole
    )
    $linha = "{0} [{1,-5}] {2}" -f (Get-Date -Format 'HH:mm:ss'), $Nivel, $Texto
    try { Add-Content -Path $Global:LOG_ATUAL -Value $linha -Encoding UTF8 -ErrorAction SilentlyContinue } catch {}

    if (-not $SemConsole) {
        $cor = switch ($Nivel) {
            'OK'    { 'Green' }
            'AVISO' { 'Yellow' }
            'ERRO'  { 'Red' }
            'PASSO' { 'Cyan' }
            default { 'Gray' }
        }
        Write-Host $linha -ForegroundColor $cor
    }
}

# ============================================================ CONFIG

function Ler-Config {
    $padrao = [ordered]@{
        UrlCatalogo   = ''
        UltimaImagem  = ''
        ModoSeguro    = $true      # true = nunca formata, so testa o boot
        WinPEPronto   = $false
        DataWinPE     = ''
    }
    if (Test-Path $Global:CFG_ARQ) {
        try {
            $j = Get-Content $Global:CFG_ARQ -Raw -Encoding UTF8 | ConvertFrom-Json
            foreach ($k in @($padrao.Keys)) {
                if ($null -ne $j.$k) { $padrao[$k] = $j.$k }
            }
        } catch { Escrever-Log "config.json ilegivel, usando padrao" AVISO -SemConsole }
    }
    return $padrao
}

function Salvar-Config {
    param([Parameter(Mandatory)]$Config)
    try {
        $Config | ConvertTo-Json -Depth 5 | Out-File $Global:CFG_ARQ -Encoding UTF8 -Force
    } catch { Escrever-Log "Falha ao salvar config: $_" ERRO -SemConsole }
}

# ============================================================ AJUDANTES

function Formatar-Tamanho {
    param([double]$Bytes)
    if ($Bytes -ge 1GB) { return ("{0:N1} GB" -f ($Bytes/1GB)) }
    if ($Bytes -ge 1MB) { return ("{0:N0} MB" -f ($Bytes/1MB)) }
    if ($Bytes -ge 1KB) { return ("{0:N0} KB" -f ($Bytes/1KB)) }
    return "$Bytes B"
}

function Testar-Admin {
    $id = [Security.Principal.WindowsIdentity]::GetCurrent()
    return ([Security.Principal.WindowsPrincipal]$id).IsInRole(
        [Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Obter-Firmware {
    <#
      Descobre se a maquina inicia em UEFI ou BIOS Legacy.
      Usa quatro metodos em sequencia: se um falhar, tenta o proximo.
    #>

    $modo   = $null
    $via    = ''
    $tenta  = @()

    # ---- Metodo 1: registro (PEFirmwareType)
    try {
        $t = (Get-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Control' `
              -Name PEFirmwareType -ErrorAction Stop).PEFirmwareType
        $tenta += "registro=$t"
        if ($t -eq 2) { $modo = 'UEFI';        $via = 'registro' }
        elseif ($t -eq 1) { $modo = 'BIOS Legacy'; $via = 'registro' }
    } catch { $tenta += 'registro=indisponivel' }

    # ---- Metodo 2: variavel de ambiente
    if (-not $modo) {
        $fe = $env:firmware_type
        $tenta += "ambiente=$fe"
        if ($fe -match 'UEFI')   { $modo = 'UEFI';        $via = 'variavel de ambiente' }
        elseif ($fe -match 'Legacy|BIOS') { $modo = 'BIOS Legacy'; $via = 'variavel de ambiente' }
    }

    # ---- Metodo 3: configuracao de boot atual (mais confiavel)
    if (-not $modo) {
        try {
            $bcd = (& bcdedit.exe /enum '{current}' 2>&1 | Out-String)
            if ($bcd -match 'winload\.efi') { $modo = 'UEFI';        $via = 'bcdedit'; $tenta += 'bcdedit=winload.efi' }
            elseif ($bcd -match 'winload\.exe') { $modo = 'BIOS Legacy'; $via = 'bcdedit'; $tenta += 'bcdedit=winload.exe' }
            else { $tenta += 'bcdedit=sem winload' }
        } catch { $tenta += 'bcdedit=falhou' }
    }

    # ---- Metodo 4: existe particao de sistema EFI no disco do Windows?
    if (-not $modo) {
        try {
            $pc  = Get-Partition -DriveLetter C -ErrorAction Stop
            $esp = Get-Partition -DiskNumber $pc.DiskNumber -ErrorAction Stop |
                   Where-Object { $_.GptType -eq '{c12a7328-f81f-11d2-ba4b-00a0c93ec93b}' }
            if ($esp) { $modo = 'UEFI'; $via = 'particao EFI'; $tenta += 'particao=EFI encontrada' }
            else {
                $d = Get-Disk -Number $pc.DiskNumber -ErrorAction Stop
                $tenta += "particao=$($d.PartitionStyle)"
                if ($d.PartitionStyle -eq 'MBR') { $modo = 'BIOS Legacy'; $via = 'disco MBR' }
            }
        } catch { $tenta += 'particao=falhou' }
    }

    $loader = $null
    if ($modo -eq 'UEFI')        { $loader = '\windows\system32\winload.efi' }
    elseif ($modo -eq 'BIOS Legacy') { $loader = '\windows\system32\winload.exe' }
    else { $modo = 'Desconhecido' }

    # ---- Secure Boot (independente do modo)
    $sbLigado = $false
    $sbTxt    = 'N/D'
    try {
        $sb = (Get-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Control\SecureBoot\State' `
               -Name UEFISecureBootEnabled -ErrorAction Stop).UEFISecureBootEnabled
        $sbLigado = ($sb -eq 1)
        $sbTxt = $(if ($sb -eq 1) { 'Ligado' } else { 'Desligado' })
    } catch {
        try {
            $sbLigado = [bool](Confirm-SecureBootUEFI -ErrorAction Stop)
            $sbTxt = $(if ($sbLigado) { 'Ligado' } else { 'Desligado' })
        } catch { $sbTxt = 'N/D' }
    }

    return [pscustomobject]@{
        Modo          = $modo
        Loader        = $loader
        Via           = $via
        Tentativas    = ($tenta -join ' | ')
        SecureBoot    = $sbLigado
        SecureBootTxt = $sbTxt
    }
}

function Obter-CaminhosAdk {
    $kits = $null
    foreach ($p in @(
        'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows Kits\Installed Roots',
        'HKLM:\SOFTWARE\Microsoft\Windows Kits\Installed Roots')) {
        $v = (Get-ItemProperty $p -Name KitsRoot10 -ErrorAction SilentlyContinue).KitsRoot10
        if ($v) { $kits = $v; break }
    }
    if (-not $kits) { return $null }

    $pe = Join-Path $kits 'Assessment and Deployment Kit\Windows Preinstallation Environment'
    $r = [pscustomobject]@{
        Kits     = $kits
        PeRoot   = $pe
        WinpeWim = Join-Path $pe 'amd64\en-us\winpe.wim'
        BootSdi  = Join-Path $pe 'amd64\Media\Boot\boot.sdi'
        Ocs      = Join-Path $pe 'amd64\WinPE_OCs'
        Completo = $false
    }
    $r.Completo = (Test-Path $r.WinpeWim) -and (Test-Path $r.BootSdi) -and (Test-Path $r.Ocs)
    return $r
}

# ============================================================ DIAGNOSTICO

function Obter-EstadoSistema {
    $cfg  = Ler-Config
    $adk  = Obter-CaminhosAdk
    $fw   = Obter-Firmware
    $cs   = Get-CimInstance Win32_ComputerSystem -ErrorAction SilentlyContinue
    $bios = Get-CimInstance Win32_BIOS -ErrorAction SilentlyContinue

    $sysDrv  = $env:SystemDrive
    $livreGb = 0
    try { $livreGb = [math]::Round((Get-PSDrive $sysDrv[0]).Free / 1GB, 1) } catch {}

    $blLigado = $false
    try {
        $bl = Get-BitLockerVolume -MountPoint $sysDrv -ErrorAction Stop
        $blLigado = ($bl.ProtectionStatus -eq 'On')
    } catch {}

    $peWim = Join-Path $Global:PASTA_PE 'boot.wim'

    $bat = Get-CimInstance Win32_Battery -ErrorAction SilentlyContinue
    $energiaOk = $true; $batTxt = 'Desktop / sem bateria'
    if ($bat) {
        $naTomada = ($bat.BatteryStatus -eq 2)
        $pct = $bat.EstimatedChargeRemaining
        $batTxt = "$pct%" + $(if ($naTomada) { ' (na tomada)' } else { ' (na bateria)' })
        $energiaOk = ($naTomada -or $pct -ge 40)
    }

    return [pscustomobject]@{
        Admin         = Testar-Admin
        Fabricante    = $(if ($cs) { $cs.Manufacturer } else { '?' })
        Modelo        = $(if ($cs) { $cs.Model } else { '?' })
        Serie         = $(if ($bios) { $bios.SerialNumber } else { '?' })
        RamGb         = $(if ($cs) { [math]::Round($cs.TotalPhysicalMemory/1GB,1) } else { 0 })
        Firmware      = $fw.Modo
        Loader        = $fw.Loader
        SecureBoot    = $fw.SecureBoot
        SecureBootTxt = $fw.SecureBootTxt
        LivreGb       = $livreGb
        BitLocker     = $blLigado
        EnergiaOk     = $energiaOk
        EnergiaTxt    = $batTxt
        AdkOk         = ($null -ne $adk -and $adk.Completo)
        Adk           = $adk
        WinPEPronto   = (Test-Path $peWim)
        WinPEArq      = $peWim
        WinPEMb       = $(if (Test-Path $peWim) { [math]::Round((Get-Item $peWim).Length/1MB) } else { 0 })
        Config        = $cfg
    }
}

# ============================================================ DOWNLOAD

function Baixar-Arquivo {
    <#
      Baixa com retomada. Usa BITS (nativo do Windows, resumivel).
      Cai para WebClient se o BITS nao estiver disponivel.
    #>
    param(
        [Parameter(Mandatory)][string]$Url,
        [Parameter(Mandatory)][string]$Destino,
        [string]$Descricao = 'Baixando',
        [scriptblock]$AoProgredir
    )

    $pasta = Split-Path $Destino -Parent
    if (-not (Test-Path $pasta)) { New-Item -ItemType Directory -Path $pasta -Force | Out-Null }

    Escrever-Log "$Descricao : $Url" PASSO

    # ---- Tentativa 1: BITS
    try {
        Import-Module BitsTransfer -ErrorAction Stop

        $job = Start-BitsTransfer -Source $Url -Destination $Destino `
                 -DisplayName $Descricao -Asynchronous -ErrorAction Stop

        while ($job.JobState -in @('Connecting','Transferring','Queued','TransientError')) {
            if ($job.BytesTotal -gt 0) {
                $pct = [math]::Round(($job.BytesTransferred / $job.BytesTotal) * 100)
                if ($AoProgredir) { & $AoProgredir $pct $job.BytesTransferred $job.BytesTotal }
                else {
                    Write-Host ("`r  {0}: {1}% ({2} de {3})   " -f $Descricao, $pct,
                        (Formatar-Tamanho $job.BytesTransferred),
                        (Formatar-Tamanho $job.BytesTotal)) -NoNewline
                }
            }
            Start-Sleep -Milliseconds 700
            $job = Get-BitsTransfer -JobId $job.JobId -ErrorAction SilentlyContinue
            if (-not $job) { break }
        }
        Write-Host ""

        if ($job -and $job.JobState -eq 'Transferred') {
            Complete-BitsTransfer -BitsJob $job
            Escrever-Log "$Descricao concluido" OK
            return $true
        }
        if ($job) {
            $erro = $job.ErrorDescription
            Remove-BitsTransfer -BitsJob $job -ErrorAction SilentlyContinue
            throw "BITS falhou: $erro"
        }
    } catch {
        Escrever-Log "BITS indisponivel ou falhou ($_). Tentando metodo alternativo." AVISO
    }

    # ---- Tentativa 2: WebClient
    try {
        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
        $wc = New-Object System.Net.WebClient
        $wc.DownloadFile($Url, $Destino)
        $wc.Dispose()
        Escrever-Log "$Descricao concluido (metodo alternativo)" OK
        return $true
    } catch {
        Escrever-Log "Download falhou: $_" ERRO
        return $false
    }
}

function Obter-Sha256 {
    param([Parameter(Mandatory)][string]$Arquivo)
    if (-not (Test-Path $Arquivo)) { return $null }
    return (Get-FileHash -Path $Arquivo -Algorithm SHA256).Hash.ToLower()
}

function Validar-Hash {
    param([string]$Arquivo, [string]$HashEsperado)
    if ([string]::IsNullOrWhiteSpace($HashEsperado)) {
        Escrever-Log "Sem hash no catalogo - validacao pulada" AVISO
        return $true
    }
    Escrever-Log "Validando integridade (pode demorar em arquivo grande)..." PASSO
    $real = Obter-Sha256 $Arquivo
    if ($real -eq $HashEsperado.ToLower()) {
        Escrever-Log "Integridade confirmada" OK
        return $true
    }
    Escrever-Log "HASH NAO CONFERE. Esperado: $HashEsperado / Obtido: $real" ERRO
    return $false
}

# ============================================================ IMAGENS LOCAIS

function Obter-ImagensLocais {
    <#
      Varre a pasta de imagens e devolve uma entrada por edicao
      encontrada dentro de cada arquivo .wim / .esd.
    #>
    param([string]$Pasta = $Global:PASTA_IMG)

    $resultado = @()
    if (-not (Test-Path $Pasta)) { return $resultado }

    $arquivos = @(Get-ChildItem -Path $Pasta -File -Recurse -ErrorAction SilentlyContinue |
                  Where-Object { $_.Extension -in @('.wim','.esd','.swm') })

    foreach ($a in $arquivos) {
        $edicoes = $null
        try {
            $edicoes = @(Get-WindowsImage -ImagePath $a.FullName -ErrorAction Stop)
        } catch {
            Escrever-Log "Nao consegui ler as edicoes de $($a.Name): $_" AVISO -SemConsole
        }

        if ($edicoes -and $edicoes.Count -gt 0) {
            foreach ($e in $edicoes) {
                $nome = $e.ImageName
                if ([string]::IsNullOrWhiteSpace($nome)) { $nome = $a.BaseName }

                $rotulo = $nome
                if ($edicoes.Count -gt 1) { $rotulo = "$nome   [$($a.Name)]" }

                $resultado += [pscustomobject]@{
                    id           = "$($a.FullName)|$($e.ImageIndex)"
                    nome         = $rotulo
                    edicao       = $nome
                    descricao    = $e.ImageDescription
                    caminho      = $a.FullName
                    arquivoNome  = $a.Name
                    indice       = $e.ImageIndex
                    tamanhoBytes = $a.Length
                    tamanhoAplicado = $e.ImageSize
                    local        = $true
                }
            }
        } else {
            # Nao deu para ler os indices: assume edicao unica
            $resultado += [pscustomobject]@{
                id           = "$($a.FullName)|1"
                nome         = $a.BaseName
                edicao       = $a.BaseName
                descricao    = '(nao foi possivel ler as edicoes deste arquivo)'
                caminho      = $a.FullName
                arquivoNome  = $a.Name
                indice       = 1
                tamanhoBytes = $a.Length
                tamanhoAplicado = 0
                local        = $true
            }
        }
    }
    return $resultado
}

# ============================================================ CATALOGO

function Obter-Catalogo {
    param([string]$Url)

    if ([string]::IsNullOrWhiteSpace($Url)) {
        $local = Join-Path $Global:RAIZ 'catalogo-exemplo.json'
        if (Test-Path $local) {
            Escrever-Log "Usando catalogo de exemplo local" AVISO
            return (Get-Content $local -Raw -Encoding UTF8 | ConvertFrom-Json)
        }
        return $null
    }

    try {
        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
        $r = Invoke-RestMethod -Uri $Url -TimeoutSec 30 -ErrorAction Stop
        Escrever-Log "Catalogo carregado: $($r.imagens.Count) imagem(ns)" OK
        return $r
    } catch {
        Escrever-Log "Nao consegui ler o catalogo: $_" ERRO
        return $null
    }
}
